<?php $cid = isset($_REQUEST['cid']) ? $_REQUEST['cid'] : 0; ?>
<!DOCTYPE html>
<html>
  <head>
    <title>Startupper</title>
    <meta charset="utf-8"/>
    <script type="text/javascript" src="js/jquery.min.js"></script>
    <script type="text/javascript" src="js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="js/bootstrap.min.js"></script>
    <script type="text/javascript" src="js/script.js"></script>
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    <link href='http://fonts.googleapis.com/css?family=Lobster&subset=latin,latin-ext' rel='stylesheet' type='text/css'>
    <link href='http://fonts.googleapis.com/css?family=Raleway:400,700,300' rel='stylesheet' type='text/css'>
  </head>
  <body>
  		<div id="header-bg">
		  	<header class="container">
			    <h1 class="span12">Startupper</h1>
			    <h2 class="span8 offset2">Aprenda tudo sobre startups de maneira fácil. Novos conteúdos toda semana para todos os níveis de conhecimento.</h2>
		  	</header>
  		</div><!-- #header-bg -->
  		<div id="action-bg">
  			<section id="action" class="container">
	  			<aside id="action-status" class="alert alert-information fade in span8 offset2">
	  				<a href="#" class="close" data-dismiss="alert">×</a>
	  			</aside>
  				<section id="action-call" class="span6 offset3 to-hide">
  					<p>Deixe seu e-mail para ser avisado do lançamento.</p>
  				</section>
	  			<form class="form-inline span6 offset3 to-hide">
	  				<input type="email" id="action-email" placeholder="deixe seu e-mail aqui"/>
	  				<input type="hidden" id="action-cid" value="<?php echo $cid ?>"/>
	  				<a href="javascript:void(0)" id="action-btn" class="btn btn-large btn-warning">Avise-me!</a>
	  			</form>
  			</section><!-- #action -->
  		</div><!-- #action-bg -->
  		<section id="support" class="container">
  			<div class="row">
	  			<div class="support-box span4">
	  				<img src="img/startupper_todos-os-niveis.png" class="support-img"/>
	  				<h3>Para todos os níveis</h3>
	  				<p>
	  					Os conteúdos ajudam quem nunca empreendeu e também quem já é experiente.
	  					Entenda o que fazer em todas as etapas, desde o dia zero.
	  				</p>
	  			</div><!-- .support-box -->
	  			<div class="support-box span4">
	  				<img src="img/startupper_passo-a-passo.png" class="support-img"/>
	  				<h3>Passo a Passo</h3>
	  				<p>
	  					Entendemos que o conteúdo técnico não é suficiente. 
	  					Por isso, os conteúdos estão recheados de passo-a-passo para que você consiga executar a teoria.
	  				</p>
	  			</div><!-- .support-box -->
	  			<div class="support-box span4">
	  				<img src="img/startupper_suporte.png" class="support-img"/>
	  				<h3>Suporte pessoal</h3>
	  				<p>
	  					Caso você tenha dúvidas, poderá entrar em contato com os profissionais do Startupper.
	  					Há muitos canais (Facebook, Twitter, e-mail, etc) para que você seja atendido da maneira que melhor convier.
	  				</p>
	  			</div><!-- .support-box -->
  			</div><!-- .row -->
  		</section><!-- #support -->
  </body>
</html>