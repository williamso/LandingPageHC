<?php
$constants['SERVER']			= 'mysql.dominio.com';			//Endereço do banco de dados
$constants['DATABASE']			= 'nome_bd';					//Nome do banco de dados
$constants['USER']				= 'usuario_bd';					//Usuário do banco de dados
$constants['PASSWORD']			= 'senha_bd';					//Senha do banco de dados
$constants['NOME_ADMIN']		= 'Fulano';						//Nome do Admin
$constants['EMAIL_ADMIN']		= 'fulano@dominio.com.br';		//Coloque um e-mail válido do seu domínio
$constants['NOME_SITE']			= 'Dominio';					//Nome do Site
$constants['EMAIL_SITE']		= 'contato@dominio.com.br';		//Coloque um e-mail válido do seu domínio